import { HydrationBoundary, dehydrate } from '@tanstack/react-query';
import { getQueryClient } from '@/shared/lib/get-query-client';

type HydrateProps = {
    queryOptions: object | object[];
    children: React.ReactNode;
};

export default async function Hydrate({ queryOptions, children }: HydrateProps) {
    const queryClient = getQueryClient();

    void queryClient.prefetchQuery(queryOptions as unknown as Parameters<typeof queryClient.prefetchQuery>[0]);

    return <HydrationBoundary state={dehydrate(queryClient)}>{children}</HydrationBoundary>;
}
