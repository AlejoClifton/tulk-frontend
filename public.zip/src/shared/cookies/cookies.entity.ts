export interface ICookies {
    user_token: string;
    refresh_token: string;
}
