import React from 'react';
import { cva } from 'class-variance-authority';
import type { ClassedComponentProps } from '@/shared/types/classed-component-props';

export const textVariants = cva('', {
    variants: {
        variant: {
            primary: 'text-primary',
            secondary: 'text-secondary',
            tertiary: 'text-tertiary',
            white: 'text-white',
            success: 'text-success',
            error: 'text-error',
        },
        size: {
            sm: 'text-sm',
            md: 'text-base',
            lg: 'text-lg',
            xl: 'text-xl',
        },
        weight: {
            normal: 'font-normal',
            medium: 'font-medium',
            semibold: 'font-semibold',
            bold: 'font-bold',
            extraBold: 'font-extrabold',
        },
    },
    defaultVariants: {
        variant: 'tertiary',
        size: 'md',
        weight: 'normal',
    },
});

export interface TextProps extends ClassedComponentProps<typeof textVariants> {
    children: React.ReactNode;
}

export const Text = ({ children, className, ...variantProps }: TextProps) => {
    return <p className={textVariants({ ...variantProps, className })}>{children}</p>;
};
