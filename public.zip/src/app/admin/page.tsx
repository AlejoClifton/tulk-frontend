import React from 'react';
import TableProducts from '@/features/products/ui/components/Table-Products';
import { getAllProductsOptions } from '@/features/products/application/queries/getAllProducts.option';
import Hydrate from '@/shared/providers/hydrate';

const Admin = () => {
    return (
        <Hydrate queryOptions={getAllProductsOptions}>
            <TableProducts />
        </Hydrate>
    );
};

export default Admin;
