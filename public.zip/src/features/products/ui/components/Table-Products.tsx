'use client';

import React from 'react';
import { Table, TableHeader, TableBody, TableRow, TableHeaderCell, TableCell, Button } from '@/shared/components/index';
import { useSuspenseQuery } from '@tanstack/react-query';
import { getAllProductsOptions } from '@/features/products/application/queries/getAllProducts.option';
import { ProductInterface } from '@/features/products/domain/product.entity';
import { StatusBadge } from '@/shared/components/ui/StatusBadge';
import { EditIcon, TrashIcon } from '@/shared/components/icons/SvgContainer';

const TableProducts = () => {
    const { data: products } = useSuspenseQuery(getAllProductsOptions);

    const headers = [
        { label: 'Nombre', key: 'name' },
        { label: 'Descripción', key: 'description' },
        { label: 'Categoría', key: 'categoryId' },
        { label: 'Imagen', key: 'mainImageUrl' },
        { label: 'Imagenes', key: 'imagesUrl' },
        { label: 'Estado', key: 'isActive' },
    ];

    return (
        <div className="container mx-auto flex flex-col gap-4 p-4">
            <Table>
                <TableHeader>
                    <TableRow>
                        {headers.map((header) => (
                            <TableHeaderCell key={header.key}>{header.label}</TableHeaderCell>
                        ))}
                        <TableHeaderCell>Acciones</TableHeaderCell>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {products.map((product: ProductInterface) => (
                        <TableRow key={product.id}>
                            {headers.map((header) => {
                                if (header.key === 'isActive') {
                                    return (
                                        <TableCell key={header.key}>
                                            <StatusBadge
                                                variant={product.isActive ? 'success' : 'error'}
                                                isActive={product.isActive}>
                                                {product.isActive ? 'Activo' : 'Inactivo'}
                                            </StatusBadge>
                                        </TableCell>
                                    );
                                }
                                return (
                                    <TableCell key={header.key} className="max-w-40 truncate">
                                        {product[header.key as keyof ProductInterface]}
                                    </TableCell>
                                );
                            })}
                            <TableCell className="flex max-w-30 items-center justify-center gap-2">
                                <Button variant="success">
                                    <EditIcon />
                                </Button>
                                <Button variant="error">
                                    <TrashIcon />
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

export default TableProducts;
