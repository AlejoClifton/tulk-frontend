import { backendApi } from '@/shared/http/clients/backend.client';
import { ProductInterface } from '../domain/product.entity';

export const getAllProducts = () => backendApi.get('/products');
export const getProductById = (id: string) => backendApi.get(`/products/${id}`);
export const createProduct = (data: ProductInterface) => backendApi.post('/products', data);
export const updateProduct = (id: string, data: ProductInterface) => backendApi.put(`/products/${id}`, data);
export const deleteProduct = (id: string) => backendApi.delete(`/products/${id}`);
